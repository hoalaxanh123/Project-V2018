﻿
//$(document).ajaxStart(function () {
//    waitingDialog.show();
//}).ajaxSuccess(function () {
//    waitingDialog.hide();
//}).ajaxError(function () {
//    waitingDialog.hide();
//}).ajaxStop(function () {
//    waitingDialog.hide();
  
//});
